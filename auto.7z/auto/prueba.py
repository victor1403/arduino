import serial, time



#time.sleep(2)
arduinoPort = serial.Serial('COM6', 9600)
Lectura = arduinoPort.readline()
print(Lectura)
