#!/usr/bin/env python
# -*- coding: utf-8 -*-

try:
    # Python 2.x
    from Tkinter import *
    from ttk import *
    from tkMessageBox import *
    import serial
    import time
except ImportError:
    # Python 3.x
    from tkinter import *
    from tkinter.ttk import *
    from tkinter.messagebox import *
    import serial
    import time

arduinoPort = serial.Serial('COM4', 9600)
bluePort1 = serial.Serial('COM5', 9600, timeout=1)
bluePort2 = serial.Serial('COM6', 9600, timeout=1)

#print bluePort1
#print bluePort2
#def mover(*args):
#    try:

ventana = Tk()
ventana.title("Auto Bluethoot - S Embebidos")

marco = Frame(ventana, padding="15 15 15 15")
marco.grid(column=0, row=0, sticky=(N, W, E, S))

sensorA = StringVar()
sensorB = StringVar()
sensorbluethooth1 = StringVar()
sensorbluethooth2 = StringVar()

text=sensorA.get
text=sensorB.get
text=sensorbluethooth1.get
text=sensorbluethooth2.get

entradaA = Entry(marco, width=7, textvariable = sensorA)
entradaA.grid(column=1, row=1, sticky=(W, E))
entradaB = Entry(marco, width=7, textvariable = sensorB)
entradaB.grid(column=1, row=2, sticky=(W, E))



Label(marco, textvariable=sensorA).grid(column=2, row=3, sticky=(W, E))
Label(marco, textvariable=sensorB).grid(column=2, row=4, sticky=(W, E))
Label(marco, textvariable=sensorbluethooth1).grid(column=2, row=5, sticky=(W, E))
Label(marco, textvariable=sensorbluethooth2).grid(column=2, row=6, sticky=(W, E))

def callback():
    arduinoPort.write("1"+sensorA.get())
    print sensorA.get() + ("*")

Button(marco, text="Distancia A", command=callback).grid(column=3, row=1, sticky=W)

def callback():
    arduinoPort.write("2"+sensorB.get())
    print sensorB.get()

Button(marco, text="Distancia B", command=callback).grid(column=3, row=2, sticky=W)

Label(marco, text="Sensor A").grid(column=2, row=1, sticky=W)
Label(marco, text="Sensor B").grid(column=2, row=2, sticky=W)
Label(marco, text="Distancia A es: ").grid(column=1, row=3, sticky=E)
Label(marco, text="Distancia B es: ").grid(column=1, row=4, sticky=E)
Label(marco, text="cm").grid(column=3, row=3, sticky=W)
Label(marco, text="cm").grid(column=3, row=4, sticky=W)


Label(marco, text="LecturaBluetooth1:").grid(column=1, row=5, sticky=E)
Label(marco, text="LecturaBluetooth2:").grid(column=1, row=6, sticky=E)
Label(marco, text="cm").grid(column=3, row=5, sticky=W)
Label(marco, text="cm").grid(column=3, row=6, sticky=W)
Label(marco, text="Sensor B").grid(column=2, row=2, sticky=W)

def lecturaB1(bluePort1):
    rawString = bluePort1.readline()
    print(rawString)
    #bluePort1.close()



Label(marco, textvariable=sensorbluethooth1).grid(column=2, row=6, sticky=(W, E))


    #bluePort1.close()

entradaA.focus()
entradaB.focus()

#ventana.bind('<Return>', mover)
ventana.bind('<Escape>', lambda x: ventana.destroy())

ventana.mainloop()
